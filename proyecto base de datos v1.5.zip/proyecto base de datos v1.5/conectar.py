import psycopg2
from tkinter import messagebox
from envioCorreo import enviar_mensaje_fecha_limite

def establecer_conexion():
    try:
        conexion = psycopg2.connect(
            user="postgres",
            password="ADMIN",
            host="127.0.0.1",
            port="5432",
            database="BIBLIOTECA"
        )
        return conexion
    except (Exception, psycopg2.Error):
        messagebox.showerror("Error de conexión", "No se pudo conectar a la base de datos.")

def validar_credenciales(nombre, contraseña):
    conexion = establecer_conexion()
    if conexion:
        try:
            cursor = conexion.cursor()

            # Consultar la base de datos para verificar las credenciales
            cursor.execute("SELECT privilegio FROM usuario WHERE nombre = %s AND contraseña = %s", (nombre, contraseña))
            resultado = cursor.fetchone()

            if resultado:
                messagebox.showinfo("Succesful", "Acceso exitoso")
                # Obtener el tipo de privilegio
                tipo_privilegio = resultado[0]  # El tipo de privilegio estará en el primer elemento de la tupla
                cursor.close()
                conexion.close()
                return tipo_privilegio  # Devolver el tipo de privilegio si se desea
            else:
                messagebox.showwarning("Credenciales inválidas", "Acceso denegado")

            cursor.close()
            conexion.close()
        except (Exception, psycopg2.Error):
            messagebox.showerror("Error", "Algo salió mal.")
    return False  # Devolver False si las credenciales no son válidas


def registrar_alumnos(codigo, nombre, carrera, correo):
    conexion = establecer_conexion()
    if conexion:
        try:
            cursor = conexion.cursor()
            cursor.execute("INSERT INTO alumno(codigo, nombre, carrera, correo) VALUES (%s, %s, %s, %s)", (codigo, nombre, carrera, correo))
            conexion.commit()  # Confirmar la operación de inserción
            messagebox.showinfo("Succesful", "Registro exitoso")
            return True
        except (Exception, psycopg2.Error) as error:
            messagebox.showwarning("Unsuccessful", "Registro fracaso")
            print("Error al registrar alumno:", error)
            return False
        finally:
            if cursor:
                cursor.close()
            if conexion:
                conexion.close()


def consultar_alumnos(tabla):
    conexion = establecer_conexion()
    if conexion:
        try:
            cursor = conexion.cursor()
            cursor.execute("SELECT codigo,nombre,carrera,correo,adeudo FROM alumno")
            datos = cursor.fetchall()

            cursor.close()
            conexion.close()
    # Mostrar los datos en la tabla
            for i, fila in enumerate(datos, start=1):
                tabla.insert("", "end", text=str(i), values=fila)

            #for fila in datos:
                #tabla.insert("", "end", values=fila)

        except (Exception, psycopg2.Error) as error:
            messagebox.showwarning("Unsuccessful", "Consulta fracaso")
            print("Error al registrar alumno:", error)
        finally:
            if cursor:
                cursor.close()
            if conexion:
                conexion.close()

def consultar_alumno_individual(tabla, codigo):
    conexion = establecer_conexion()
    if conexion:
        try:
            cursor = conexion.cursor()
            cursor.execute("SELECT codigo, nombre, carrera, correo, adeudo FROM alumno WHERE codigo = %s", (codigo,))
            alumno = cursor.fetchone()

            cursor.close()
            conexion.close()

            tabla.delete(*tabla.get_children())  # Limpiar la tabla

            if alumno:
                tabla.insert("", "end", values=alumno)
            else:
                messagebox.showwarning("Error", "No se encontró ningún alumno con el código proporcionado.")

        except Exception as error:
            messagebox.showwarning("Error", "Error al consultar el alumno.")
            print("Error al consultar el alumno:", error)
        finally:
            if cursor:
                cursor.close()
            if conexion:
                conexion.close()

def registrar_profesor(codigo, nombre, carrera, correo):
    conexion = establecer_conexion()
    if conexion:
        try:
            cursor = conexion.cursor()
            cursor.execute("INSERT INTO profesor(codigo, nombre, carrera, correo) VALUES (%s, %s, %s, %s)", (codigo, nombre, carrera, correo))
            conexion.commit()  # Confirmar la operación de inserción
            messagebox.showinfo("Succesful", "Registro exitoso")
            return True
        except (Exception, psycopg2.Error) as error:
            messagebox.showwarning("Unsuccessful", "Registro fracaso")
            print("Error al registrar profesor:", error)
            return False
        finally:
            if cursor:
                cursor.close()
            if conexion:
                conexion.close()

def consultar_profesores(tabla):
    conexion = establecer_conexion()
    if conexion:
        try:
            cursor = conexion.cursor()
            cursor.execute("SELECT codigo,nombre,carrera,correo,adeudo FROM profesor")
            datos = cursor.fetchall()

            cursor.close()
            conexion.close()
    # Mostrar los datos en la tabla
            for i, fila in enumerate(datos, start=1):
                tabla.insert("", "end", text=str(i), values=fila)

            #for fila in datos:
                #tabla.insert("", "end", values=fila)

        except (Exception, psycopg2.Error) as error:
            messagebox.showwarning("Unsuccessful", "Consulta fracaso")
            print("Error al registrar profesor:", error)
        finally:
            if cursor:
                cursor.close()
            if conexion:
                conexion.close()

def consultar_profesor_individual(tabla, codigo):
    conexion = establecer_conexion()
    if conexion:
        try:
            cursor = conexion.cursor()
            cursor.execute("SELECT codigo, nombre, carrera, correo, adeudo FROM profesor WHERE codigo = %s", (codigo,))
            profesor = cursor.fetchone()

            cursor.close()
            conexion.close()

            tabla.delete(*tabla.get_children())  # Limpiar la tabla

            if profesor:
                tabla.insert("", "end", values=profesor)
            else:
                messagebox.showwarning("Error", "No se encontró ningún profesor con el código proporcionado.")

        except Exception as error:
            messagebox.showwarning("Error", "Error al consultar el profesor.")
            print("Error al consultar el profesor:", error)
        finally:
            if cursor:
                cursor.close()
            if conexion:
                conexion.close()

def registrar_libro(isbn, titulo, autor, editorial, año_public, ejemplar, estado):
    ejemplar = int(ejemplar) + 1
    conexion = establecer_conexion()
    repetido = False
    fallidos = 0
    if conexion:
        try:
            cursor = conexion.cursor()
            # Verificar si la tupla ya existe en la base de datos
            # Si la tupla no existe, procede con la inserción
            for i in range(1, ejemplar):
                numEjemplar = int(i)
                cursor.execute("SELECT * FROM libro WHERE isbn = %s AND titulo = %s AND autor = %s AND editorial = %s AND año_public = %s AND num_ejemplar = %s AND estado = %s", (isbn, titulo, autor, editorial, año_public, numEjemplar, estado))
                if cursor.fetchone():
                    repetido = True
                    fallidos += 1 
                    pass
                else:
                    cursor.execute("INSERT INTO libro(isbn, titulo, autor, editorial, año_public, num_ejemplar, estado) VALUES (%s, %s, %s, %s, %s, %s, %s)", (isbn, titulo, autor, editorial, año_public, numEjemplar, estado))
                    conexion.commit()  # Confirmar la operación de inserción
                    repetido = False

            if repetido == False:
                numEjemplar = numEjemplar - fallidos
                numEjemplar = str(numEjemplar)
                messagebox.showinfo("Succesful", "Registros exitosos: " + numEjemplar)
                return True
            else:
                messagebox.showwarning("Error", "La tupla ya existe en la base de datos.")
                return False

        except (Exception, psycopg2.Error) as error:
            messagebox.showwarning("Error", "Registro fracaso")
            print("Error al registrar libro:", error)
            return False
        finally:
            if cursor:
                cursor.close()
            if conexion:
                conexion.close()

def consultar_libros(tabla):
    conexion = establecer_conexion()
    if conexion:
        try:
            cursor = conexion.cursor()
            cursor.execute("SELECT isbn, titulo, autor, editorial, año_public, num_ejemplar, estado FROM libro")
            datos = cursor.fetchall()

            cursor.close()
            conexion.close()
    # Mostrar los datos en la tabla
            for i, fila in enumerate(datos, start=1):
                tabla.insert("", "end", text=str(i), values=fila)

        except (Exception, psycopg2.Error) as error:
            messagebox.showwarning("Unsuccessful", "Consulta fracaso")
            print("Error al registrar libro:", error)
        finally:
            if cursor:
                cursor.close()
            if conexion:
                conexion.close()

def consultar_libros_individual(tabla, isbn):
    conexion = establecer_conexion()
    if conexion:
        try:
            cursor = conexion.cursor()
            cursor.execute("SELECT isbn, titulo, autor, editorial, año_public, num_ejemplar, estado FROM libro WHERE isbn = %s", (isbn,))
            libros = cursor.fetchall() 

            cursor.close()
            conexion.close()

            tabla.delete(*tabla.get_children())  # Limpiar la tabla

            if libros:
                for libro in libros:
                    tabla.insert("", "end", values=libro)
            else:
                messagebox.showwarning("Error", "No se encontró ningún libro con el isbn proporcionado.")

        except Exception as error:
            messagebox.showwarning("Error", "Error al consultar el libro.")
            print("Error al consultar el libro:", error)
        finally:
            if cursor:
                cursor.close()
            if conexion:
                conexion.close()


def registrar_prestamo(codigo_cliente, correo_cliente, isbn, ejemplar, fecha_prestamo, fecha_limite):
    conexion = establecer_conexion()
    if conexion:
        try:
            cursor = conexion.cursor()
            #REGISTRAR
            cursor.execute("INSERT INTO prestamo(codigo_cliente, correo_cliente, isbn, num_ejemplar, fecha_prestamo, fecha_limite) VALUES (%s, %s, %s, %s, %s, %s)", (codigo_cliente, correo_cliente, isbn, ejemplar, fecha_prestamo, fecha_limite))
            #MARCAR COMO NO DISPONIBLE
            cursor.execute("UPDATE libro SET estado = %s WHERE isbn = %s AND num_ejemplar = %s", ("No disponible", isbn, ejemplar))
            conexion.commit()  # Confirmar la operación de inserción
            #EXTRAER NOMBRE
            cursor.execute("SELECT nombre FROM alumno WHERE codigo = %s", (codigo_cliente,))
            nombre_cliente_alumno = cursor.fetchone()
            if nombre_cliente_alumno:  
                nombre_cliente = nombre_cliente_alumno[0]  # Acceder al primer elemento de la tupla
            else:
                cursor.execute("SELECT nombre FROM profesor WHERE codigo = %s", (codigo_cliente,))
                nombre_cliente_profesor = cursor.fetchone()
                nombre_cliente = nombre_cliente_profesor[0]

            messagebox.showinfo("Succesful", "Registro exitoso")
            enviar_mensaje_fecha_limite(nombre_cliente,codigo_cliente,correo_cliente,isbn,ejemplar,fecha_prestamo,fecha_limite)
            return True
        except (Exception, psycopg2.Error) as error:
            messagebox.showwarning("Unsuccessful", "Registro fracaso")
            print("Error al registrar prestamo:", error)
            return False
        finally:
            if cursor:
                cursor.close()
            if conexion:
                conexion.close()

def consultar_prestamos(tabla):
    conexion = establecer_conexion()
    if conexion:
        try:
            cursor = conexion.cursor()
            cursor.execute("SELECT codigo_cliente, correo_cliente, isbn, num_ejemplar, fecha_prestamo, fecha_limite, fecha_entrega FROM prestamo")
            datos = cursor.fetchall()

            cursor.close()
            conexion.close()
    # Mostrar los datos en la tabla
            for i, fila in enumerate(datos, start=1):
                tabla.insert("", "end", text=str(i), values=fila)

            #for fila in datos:
                #tabla.insert("", "end", values=fila)

        except (Exception, psycopg2.Error) as error:
            messagebox.showwarning("Unsuccessful", "Consulta fracaso")
            print("Error al registrar libro:", error)
        finally:
            if cursor:
                cursor.close()
            if conexion:
                conexion.close()

def obtener_codigo_alumno(tabla,columna):
    conexion = establecer_conexion()
    cursor = conexion.cursor()
    #Tomar colum

    cursor.execute(f"SELECT DISTINCT {columna} FROM {tabla}")
    #resultados = cursor.fetchall()
    resultados = [registro[0] for registro in cursor.fetchall()]
    
    cursor.close()
    conexion.close()

    return resultados

def obtener_numero_ejemplar(libro_seleccionado):
    conexion = establecer_conexion()
    cursor = conexion.cursor()
    cursor.execute("SELECT num_ejemplar FROM libro WHERE isbn = %s and estado = %s", (libro_seleccionado,"Disponible",))
    ejemplaresDisponibles = [registro[0] for registro in cursor.fetchall()]

    cursor.close()
    conexion.close()

    return ejemplaresDisponibles

def obtener_correo_cliente(codigo,tabla):
    conexion = establecer_conexion()
    cursor = conexion.cursor()
    cursor.execute(f"SELECT correo FROM {tabla} WHERE codigo = %s", (codigo,))
    correoCliente = cursor.fetchall()

    cursor.close()
    conexion.close()

    return correoCliente
